from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class MatchRequest(BaseModel):
    home_team: str
    away_team: str

@app.post("/predict")
def predict(match: MatchRequest):
    return {
        "win_prob": {"home": 0.55, "draw": 0.25, "away": 0.20},
        "expected_goals": {"home": 1.8, "away": 1.2},
        "yellow_cards": {"home": 1.5, "away": 1.1}
    }